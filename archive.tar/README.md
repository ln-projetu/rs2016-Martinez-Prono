# ptar

ptar is an C project developped during systems and networks courses. 
Its aim is to extract efficiently a tarball. The program uses threads in order to perform the extraction.

# Project structure 

 - bin: Contains the ptar executable.
 - build:  Contains all object files.
 - doc: Documentation of ptar program.
 - include: All project header files.
 - src: Contains the application’s source files.
 - test: All test code files.

# Authors

@martyrisateur (Lucas Martinez), lucas.martinez@telecomnancy.net
@mcdostone (Yann Prono), yann.prono@telecomnancy.net
